# Ionic Cordova Based Shopping Cart 

##UPDATE (10-07-2016)
[FoodKart v0.3](https://github.com/arjunsk/ionic-firebase-shopping-cart) is released. Read the complete [tutorial series here](http://www.arjunsk.com/tag/firebase/). 
![FoodKart V0.3 ](https://raw.githubusercontent.com/arjunsk/ionic-firebase-shopping-cart/master/fk-latest.png)

####UPDATE (20-03-2016)
![Food Cart ](https://raw.githubusercontent.com/arjunsk/ionic-shopping-cart-2/master/%23SCREEN_SHOT/screen.png)
[FoodKart V 0.2 ](https://github.com/arjunsk/shopping-cart)  is out.


FoodKart is an simple Food Purchase App, build in HTML5 - Cordova. Since it is a web app, you can easily port it to all the platforms.

Here is a complete set of Tutorials for Ionic Cordova:

[Ionic Cordova Shopping Cart ](http://www.arjunsk.com/html5/how-to-build-html5-app-using-ionic-cordova-part-4)


