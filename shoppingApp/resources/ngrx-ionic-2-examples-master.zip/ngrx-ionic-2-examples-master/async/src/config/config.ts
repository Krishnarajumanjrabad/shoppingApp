export let CONFIG = 
{
    logger: {
        isActive: true
    }
}